﻿using System.Web.UI;

namespace CAP499_Capstone.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}